# myK9Show — Handoff to Claude Code

You're picking up a redesign that has been fully specced in mockup form. Your job is to build it into the real app at `myk9-platform/`.

---

## Read these three files first, in this order

1. **`myk9-platform/CLAUDE.md`** and **`myk9-platform/DESIGN.md`** — the real codebase's own docs. Trumps anything in the mockup if they conflict.
2. **`DESIGN-NOTES.md`** (this project root) — every design decision, locked in. The "source of truth" for what the redesign is.
3. **`myK9Show Redesign.html`** (open in the preview pane) — all 15 screens laid out as a design canvas. This is the visual spec.

Everything else (`components.jsx`, `screens.jsx`, `scentwork-*.jsx`, etc.) is mockup implementation — read it for patterns and copy, but **do not port it line-for-line**. It's inline React with CSS variables, no Tailwind, no real data layer. The production app likely has its own conventions.

---

## How to approach the build

**Use existing components from the real codebase.** When the mockup uses `Card`, `Button`, `Chip`, `Icon`, `SectionTitle`, etc., map them to whatever already exists in `myk9-platform/packages/`. Don't recreate primitives that already exist.

**When the mockup introduces something new** (the secretary context-bar, Class Run Sheet with inline result entry, the "Where to be & when" timeline, Dog title-progress rows), build it following the existing codebase's component conventions.

**Preserve the decisions, not the code.** The mockup's job was to pin down:
- IA and navigation structure
- Copy (use the terminology cheat sheet in DESIGN-NOTES verbatim)
- Role-aware behavior (exhibitor vs secretary)
- The data model (Show → Days → Trials → Classes → Entries → Result)
- Senior-friendly defaults (18px body, 64px primary CTAs, no icon-only nav)

How you *implement* those is up to the codebase's idioms.

---

## Build order (recommended)

1. **Tokens + primitives** — port the color/type tokens from `assets/colors_and_type.css` + `tokens.css` into the real design-system package if they aren't already there. Establish `Card`, `Button` (with `size="xl"`), `Chip` variants, `PageShell`, `DetailShell`.
2. **Browse + Detail shells** (Direction B row-cards, unified tabbed detail) — unlocks 10 pages at once.
3. **Auth + Settings** — see the "Deferred pages" section of DESIGN-NOTES. Simple, gets users in the door.
4. **Exhibitor flow** — Browse shows → Show detail → Sign up → Payment → My entries → Class detail before/after.
5. **Secretary flow** — My Shows → in-show mode → Class Run Sheet (the hardest and most important page — budget accordingly).
6. **Dog detail with title progress.**
7. **Notifications, premium-list wizard, transactional emails.**

---

## What's explicitly NOT in v1

See the "Not in v1" section of DESIGN-NOTES for the full list. Don't invent these:
- Mobile breakpoints (desktop-first — tablet/phone is a later phase)
- Judge app (judges use paper scoresheets)
- Physical scoresheet digitization
- Social login
- DMs / messaging between users
- Public-facing show results pages (results live inside authenticated show detail)
- Payment refunds flow
- Other competition types beyond Scent Work (conformation, obedience, agility — all later phases)

---

## Key quick-reference

- **Two roles, one codebase.** `role="exhibitor" | "secretary"` prop threaded through `PageShell` / `Sidebar` / `DetailShell`. Secretary gets terracotta accent, different sidebar, extra tabs.
- **Copy matters.** "Sign up for this show" not "Register entry." Full table in DESIGN-NOTES.
- **The Class Run Sheet is the magic page.** Check-in + run order + inline result entry on one screen. Read that section of DESIGN-NOTES carefully.
- **Senior-first.** 18px body default, 64px primary CTAs, icon + label + sub-label in nav, breadcrumbs always visible, help card on every detail page.

---

## When you hit something unspecced

The mockup covers the happy path. When you hit an empty state, error state, loading state, permission-denied state, or anything not explicitly drawn — follow the codebase's existing conventions. If the codebase doesn't have a convention, use the closest pattern from the mockup (e.g. the empty-state card on the Past shows section) and keep it consistent.

If you hit a real fork in the road that would change user-visible behavior, stop and ask the PM rather than guessing.
